/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package personnel;

/**
 *
 * @author PC
 */
public class Person {
    private String name;
    private Education title;
	
    public Person(String name, Education title) {
        this.name = name;
	this.title = title;
    }
	
    @Override
    public String toString(){
        return this.name + ", " + this.title;
    }
	
    public Education getEducation() {
        return this.title;
    }
    
}

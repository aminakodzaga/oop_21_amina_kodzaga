/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package week14;
import java.util.Scanner;
import personnel.Education;
import personnel.Employees;
import personnel.Person;
/**
 *
 * @author PC
 */
public class Week14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         System.out.print("unesi string: ");
	Scanner reader = new Scanner(System.in);
	String word = reader.nextLine();
	isAWeekDay(word);
        allVowels(word);
        clockTime(word);
        
        Person arto = new Person("Arto", Education.D);
        System.out.println(arto);
        
        Employees university = new Employees();
        university.add(new Person("Matti", Education.D));
        university.add(new Person("Pekka", Education.GRAD));
        university.add(new Person("Arto", Education.D));

        university.print();

        university.fire(Education.GRAD);

        System.out.println("==");

        university.print();
    }
	
    public static boolean isAWeekDay(String string) {
	if(string.matches("mon,tue,wed,thu,fri,sat,sun")){
            System.out.println("This form is okay");
            return true;
	}else{
            System.out.println("The form is wrong");
            return false;
	}
    }
	
    public static boolean allVowels(String string) {
	if(string.matches("(a,e,i,o,u)")){
            System.out.println("The form is okay");
            return true;
	}else{
            System.out.println("The form is wrong");
            return false;
	}
    }
    
    public static boolean clockTime(String string){
        if(string.matches("(((0|1)[0-9])|(2[0-3])):[0-5][0-9]:[0-5][0-9]")){
            System.out.println("The form is okay");
            return true;
	}else{
            System.out.println("The form is wrong");
            return false;
	}
    }
}
    
    


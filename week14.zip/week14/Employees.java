/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package personnel;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author PC
 */
public class Employees {
    private ArrayList<Person> employees;

    public Employees(){
        this.employees = new ArrayList<Person>();
    }

    public void add(Person person) {
        this.employees.add(person);
    }

    public void add(ArrayList<Person> persons){
        for(Person p : persons){
            this.employees.add(p);
        }
    }

    public void print(){
        Iterator<Person> iterator = employees.iterator();

        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    public void print(Education education){
        Iterator<Person> iterator = employees.iterator();
        
        while (iterator.hasNext()) {
           Person nextPerson = iterator.next();
           if(nextPerson.getEducation().equals(education)){
                System.out.println(nextPerson);
           }
        }
    }

    public void fire(Education education){
        Iterator<Person> iterator = employees.iterator();

        while (iterator.hasNext()) {
            if (iterator.next().getEducation().equals(education)) {
                iterator.remove();
            }
        }
    }
}

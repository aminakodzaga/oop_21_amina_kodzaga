/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package people;

/**
 *
 * @author PC
 */
public class Teacher extends Person{
    private int salary;
    
    public Teacher(String n, String a, int s){
       super(n, a);
       this.salary = s;
    }
    
    @Override
    public String toString() {
        return super.toString() + "\n\tsalary " + this.salary;
    }
}

   
    




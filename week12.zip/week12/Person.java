/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package people;

/**
 *
 * @author PC
 */
public class Person {
    private String name;
    private String address;
    
    public Person(String n, String a){
        this.name = n; 
        this.address = a;
    }
    
    public String toString(){
        return this.name + "\n\t" + this.address;
    }
    
}


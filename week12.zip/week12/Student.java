/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package people;

/**
 *
 * @author PC
 */
public class Student extends Person{
    private int credits;
    
    public Student(String n, String a){
       super(n, a);
       this.credits = 0;
    }
    
    public int credits(){
        return this.credits;
    }
    
    public void study(){
        this.credits++;
    }
    
    @Override
    public String toString() {
        return super.toString() + "\n\tcredits " + this.credits;
    }
}

    

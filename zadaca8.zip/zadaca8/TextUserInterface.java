/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zadaca8;

import java.util.Scanner;

/**
 *
 * @author PC
 */
class TextUserInterface {
  private Scanner reader;
  private Dictionary dictionary;

    public TextUserInterface(Scanner reader, Dictionary dictionary) {
        this.reader = reader;
        this.dictionary = dictionary;
       
           // System.out.println(reader.nextLine());
       
        System.out.println(" quit the text user interface\n\translate - asks a word - adds a word pair to the dictionary");
    }

    public void start() {
        while (true) {
            System.out.println("");
            System.out.print("Statement: ");
            String command = reader.nextLine();

             if (command.equals("quit")){
                System.out.println("Cheers");
                break;
            } else {
                handleCommand(command);
            }
        }
    }

    public void handleCommand(String command) {
       if (command.equals("add")){
          System.out.print("In Finnish: ");
          String word = reader.nextLine();
          System.out.print("Translation: ");
          String translation = reader.nextLine();
          add(word, translation);
        } else if (command.equals("translate")){
           System.out.print("Give a word: ");
           String word = reader.nextLine();
           System.out.println("Translation: " + translate(word));
        }else{
            System.out.println("Uknown statement");
        }
    }
    
    public String translate(String word){
      return  dictionary.translate(word);
    }
    
    public void add(String word, String translation){
        dictionary.add(word, translation);
    }
}
    


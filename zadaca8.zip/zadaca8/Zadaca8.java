/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package zadaca8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author PC
 */
public class Zadaca8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*HashMap<String, String> names = new HashMap<String, String>();
        
        names.put("matt", "mage");
        names.put("mikael", "mixu");
        names.put("arto", "arppa");
        
        System.out.println(names.get("mikael"))*/
       /* PromissoryNote mattisNote = new PromissoryNote();

        mattisNote.setLoan("Arto", 51.5);
        mattisNote.setLoan("Mikael", 30);
        mattisNote.setLoan("Arto", 11.5);

        System.out.println(mattisNote.howMuchIsDebt("Arto"));
        System.out.println(mattisNote.howMuchIsDebt("Joel"));*/
       /*Dictionary dictionary = new Dictionary();
       dictionary.add("apina", "monkey");
       dictionary.add("banaani", "banana");
       dictionary.add("cembalo", "harpsichord");
       
        System.out.println(dictionary.translate("apina"));
        System.out.println(dictionary.translate("porkkana"));
        
        System.out.println(dictionary.amountOfWords());
        
        ArrayList<String> translations = dictionary.translationList();
        
        for(String translation: translations){
            System.out.println(translation);
        
    }*/
       /*String input = "translate\n" + "monkey\n"  +
                   "translate\n" + "cheese\n" +
                   "add\n"  + "cheese\n" + "juusto\n" +
                   "translate\n" + "cheese\n" +
                   "quit\n";
       
       Scanner reader = new Scanner(input);
       Dictionary dictionary = new Dictionary();
       
       TextUserInterface ui = new TextUserInterface(reader, dictionary);
       ui.start(); */
    
    }
}
